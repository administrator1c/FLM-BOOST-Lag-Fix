# FLM BOOST – Lag Fix 2.0

Ứng dụng Android native Kotlin, công cụ hỗ trợ tối ưu thiết bị khi sử dụng FL Studio Mobile. Đây KHÔNG phải app làm nhạc và không mô phỏng giao diện FL Studio Mobile.

## Chức năng
- Giám sát RAM khả dụng và mức sử dụng RAM ước tính.
- Theo dõi dung lượng trống trong phân vùng dữ liệu ứng dụng.
- Đọc trạng thái nhiệt Android (Android 10+).
- Preset hướng dẫn Low Load / Balanced / Performance.
- Mở cài đặt pin Android, trang thông tin FL Studio Mobile và mở FL Studio Mobile (nếu package ID khớp).
- Checklist giảm audio crackle, lag và độ trễ.

## Build APK
1. Cài Android Studio và JDK 17.
2. Mở thư mục dự án bằng Android Studio.
3. Chờ Gradle Sync.
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

Terminal: `gradle assembleDebug`

## Giới hạn quan trọng
Ứng dụng Android thông thường không được phép kill tiến trình/giải phóng RAM của ứng dụng khác, ép xung CPU/GPU, thay đổi audio buffer của FL Studio Mobile hoặc bảo đảm giảm latency. Các preset là hướng dẫn thao tác an toàn; người dùng tự xác nhận các thay đổi trong Cài đặt Android/FL Studio Mobile. Chỉ số bộ nhớ trống ở đây là dung lượng phân vùng dữ liệu app, không đại diện toàn bộ dung lượng lưu trữ thiết bị.

## Package FL Studio Mobile
Mã nguồn dùng package ID `com.imageline.FLM` để mở app. Nếu phiên bản bạn cài dùng ID khác, cập nhật danh sách `candidates` trong `findFlmPackage()` rồi build lại.
