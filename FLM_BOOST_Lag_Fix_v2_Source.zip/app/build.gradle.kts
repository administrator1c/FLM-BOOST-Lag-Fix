plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.flmboost.lagfix"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.flmboost.lagfix"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
